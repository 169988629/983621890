#!/bin/bash

ps_num=`ps | grep v2ray | grep -v grep | wc -l`
if [ $ps_num -lt 1 -a "$1" == "-r" ]; then
	nohup /mnt/rootfs/home/run_bin/v2ray -config /mnt/rootfs/home/run_bin/ok.json 1>/dev/null 2>&1 &
	timenew=`date`
	echo "$timenew: Run /home/v2ray"
fi

if [ $ps_num -gt 0 -a "$1" == "-k" ]; then
	killall v2ray
	timenew=`date`
	echo "$timenew: Kill /home/v2ray"
fi
