while true ; do
	echo "aaaaa"
	/mnt/rootfs/home/run_bin/script/monitor.sh -r >> /mnt/rootfs/home/run_bin/log/log.txt
	sleep 60
done
