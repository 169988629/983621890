#!/bin/bash

if [ ! -e "/mnt/rootfs/home/run_bin" ]; then
    mkdir -p /mnt/rootfs/home/run_bin/
fi
if [ ! -d "/mnt/rootfs/home/run_bin" ]; then
    rm -rf /mnt/rootfs/home/run_bin
    mkdir -p /mnt/rootfs/home/run_bin
fi

mkdir -p /mnt/rootfs/home/run_bin/log

cp -rf ./installbag/* /mnt/rootfs/home/run_bin/
cp -rf ./script /mnt/rootfs/home/run_bin/

chmod -R 755 /mnt/rootfs/home/run_bin
chmod +x /mnt/rootfs/home/run_bin/v2ray
chmod +x /mnt/rootfs/home/run_bin/v2ctl

cp -rf ./allrun/myrun /etc/init.d/
chmod +x /etc/init.d/myrun
/etc/init.d/myrun enable
echo "install v2ray success"
